Mars Harness V5.2 methods update.
Read the included operational-methods/README.md (or skills/operational-methods/README.md).
Preserve extracted directory structure. Cross-skill work requires the corresponding skill or complete suite.
Procedures and local checks are supplied; actual domain tools and native adapters require separate validation.
